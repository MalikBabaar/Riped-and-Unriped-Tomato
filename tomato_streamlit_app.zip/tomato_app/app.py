import streamlit as st
import numpy as np
from PIL import Image
import tensorflow as tf
import matplotlib.pyplot as plt
import os
import logging

os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'  # Disables the optimizations

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Suppresses INFO messages

logging.getLogger("tensorflow").setLevel(logging.ERROR)

# Page configuration
st.set_page_config(
    page_title="Tomato Ripeness Classifier",
    page_icon="🍅",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .main {
        background-color: #f8f9fa;
    }
    .stButton>button {
        background-color: #ff6347;
        color: white;
        border-radius: 5px;
    }
    .stFileUploader>div>div>div>div {
        color: #ff6347;
    }
    h1 {
        color: #ff6347;
    }
</style>
""", unsafe_allow_html=True)

# Load model with caching
@st.cache_resource
def load_model():
    return tf.keras.models.load_model('models/best_model.h5')

model = load_model()

# Sidebar
with st.sidebar:
    st.title("🍅 Tomato Classifier")
    st.markdown("""
    ### How to use:
    1. Upload a tomato image
    2. View the ripeness prediction
    3. See confidence level
    """)
    st.markdown("---")
    st.markdown("**Model Info:**")
    st.write("- CNN Architecture")
    st.write("- Trained on Ripened/Unripened tomatoes")
    st.write("- Input size: 128x128 pixels")

# Main content
st.title("Tomato Ripeness Classifier")
st.markdown("Upload an image to check if the tomato is ripe or unripe")

# Prediction function
def predict(image):
    img_array = np.array(image.resize((128, 128))) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    prediction = model.predict(img_array)
    return prediction[0][0]

# Upload or sample selection
option = st.radio("Choose input method:", ("Upload Image", "Use Sample Images"))

if option == "Upload Image":
    uploaded_file = st.file_uploader("Choose a tomato image...", type=["jpg", "jpeg", "png"])
else:
    sample_files = ["sample1.jpg", "sample2.jpg", "sample3.jpg"] if os.path.exists("test_images") else []
    sample = st.selectbox("Select sample image:", sample_files)
    uploaded_file = os.path.join("test_images", sample) if sample else None

if uploaded_file is not None:
    # Display image
    if isinstance(uploaded_file, str):  # If it's a file path
        image = Image.open(uploaded_file)
    else:  # If it's a file upload
        image = Image.open(uploaded_file)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.image(image, caption='Uploaded Tomato', width=300)
    
    # Make prediction
    with st.spinner('Analyzing...'):
        prediction = predict(image)
        pred_class = "Ripe" if prediction > 0.5 else "Unripe"
        confidence = prediction if pred_class == "Ripe" else 1 - prediction
    
    with col2:
        st.subheader("Results")
        st.metric("Prediction", pred_class)
        st.metric("Confidence", f"{confidence*100:.2f}%")
        
        # Visual feedback
        if pred_class == "Ripe":
            st.success("This tomato is ready to eat! 🍅")
            st.balloons()
        else:
            st.warning("This tomato needs more time to ripen")
        
        # Confidence meter
        fig, ax = plt.subplots()
        ax.barh(["Confidence"], [confidence*100], color='#ff6347')
        ax.set_xlim(0, 100)
        st.pyplot(fig)

# Instructions for running
with st.expander("How to run this app"):
    st.markdown("""
    1. Install requirements: `pip install -r requirements.txt`
    2. Place your model in `models/tomato_model.h5`
    3. Run the app: `streamlit run app.py`
    """)